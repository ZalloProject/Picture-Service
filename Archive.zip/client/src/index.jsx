/* eslint-disable import/extensions */
import ReactDOM from 'react-dom';
import React from 'react';
import Main from './Main.jsx';


ReactDOM.render(<Main />, document.getElementById('photos'));
